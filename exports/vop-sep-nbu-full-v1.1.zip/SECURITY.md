# Політика безпеки

## 🔒 Конфіденційність проекту

Цей репозиторій містить **конфіденційну** документацію системи Verification of Payee для СЕП НБУ.

**Рівень конфіденційності:** ПРИВАТНИЙ
**Доступ:** Тільки авторизовані співробітники НБУ та партнери

## 🛡️ Захист даних

### Що НЕ можна commit'ити:

❌ **Credentials та ключі:**
- API keys
- OAuth client secrets
- Database passwords
- Private keys для mTLS
- JWT signing keys

❌ **Персональні дані:**
- Реальні IBAN клієнтів
- Імена реальних клієнтів (використовуйте тестові дані)
- ІПН, ЄДРПОУ реальних осіб/компаній
- Телефони, email

❌ **Production конфігурація:**
- Production URLs
- Production database connection strings
- Real certificate fingerprints

### ✅ Що можна commit'ити:

- 📄 Документація
- 📊 Специфікації (OpenAPI, JSON Schema)
- 📏 Правила та алгоритми
- 💡 Приклади з **тестовими** даними
- 🔧 Референсний код (без credentials)

### Приклади тестових даних:

```json
// ✅ ПРАВИЛЬНО - тестові дані
{
  "iban": "UA213223130000026007233566001",
  "name": "ШЕВЧЕНКО ТАРАС ГРИГОРОВИЧ",
  "inn": "1234567890"
}

// ❌ НЕПРАВИЛЬНО - реальні дані
{
  "iban": "UA91...", // реальний IBAN
  "name": "Іванов Іван Іванович", // реальна особа
  "inn": "3456789012" // реальний ІПН
}
```

## 🔐 Безпечне зберігання credentials

### Використовуйте змінні оточення:

```bash
# .env (НЕ commit'ити!)
VOP_ROUTER_URL=https://vop-router.sep.nbu.gov.ua
CLIENT_ID=yourbank_client_id
CLIENT_SECRET=super_secret_password
```

### Додайте до .gitignore:

```
.env
.env.local
.env.production
secrets/
credentials/
*.key
*.pem
*.pfx
```

## 🚨 Повідомлення про вразливості

Якщо ви знайшли вразливість у документації або коді:

### НЕ створюйте публічний issue!

Замість цього:

1. **Email:** security@bank.gov.ua
2. **Тема:** [SECURITY] VoP Vulnerability Report
3. **Опис:**
   - Тип вразливості
   - Файл/компонент
   - Можливий вплив
   - Рекомендації щодо виправлення

### Приклад повідомлення:

```
Тема: [SECURITY] VoP Vulnerability Report

Опис: У файлі rules/validation_rules.md виявлено слабку валідацію IBAN,
що може дозволити bypass checksum перевірки.

Файл: rules/validation_rules.md, рядок 145
Вплив: Можливість передачі невалідних IBAN
Рекомендація: Додати додаткову перевірку mod 97

Контакт: [ваш email]
```

## 🔒 Управління доступом

### Рівні доступу:

| Роль | Права | Хто |
|------|-------|-----|
| **Admin** | Повний доступ, управління членами | НБУ - керівництво проекту |
| **Maintainer** | Merge PR, управління issues | НБУ - технічна команда |
| **Developer** | Create PR, commit до своїх гілок | НБУ + партнери (з NDA) |
| **Read-only** | Тільки читання | Аудитори, compliance |

### Запит на доступ:

1. Звернутися до project owner: sep@bank.gov.ua
2. Вказати:
   - ПІБ та посада
   - Організація (НБУ або банк-партнер)
   - Причина доступу
   - Необхідний рівень доступу
3. Підписати NDA
4. Отримати запрошення

## 🔑 GitHub Security Features

### Обов'язково налаштувати:

✅ **Two-Factor Authentication (2FA)**
- GitHub Settings → Security → Enable 2FA

✅ **SSH Keys** (замість паролів)
```bash
ssh-keygen -t ed25519 -C "your_email@bank.gov.ua"
# Додати public key до GitHub
```

✅ **GPG Signing** (для commit)
```bash
git config --global commit.gpgsign true
```

### Recommended Security Settings:

```bash
# Завжди підписувати commit
git config --global commit.gpgsign true

# Використовувати SSH
git config --global url."git@github.com:".insteadOf "https://github.com/"

# Auto-sign commits
git config --global user.signingkey [YOUR_GPG_KEY]
```

## 📋 Security Checklist перед commit

- [ ] Немає credentials у коді
- [ ] Немає реальних персональних даних
- [ ] .gitignore налаштовано правильно
- [ ] Тільки тестові дані у прикладах
- [ ] Документація не розкриває внутрішню інфраструктуру
- [ ] Commit message не містить конфіденційної інформації

## 🔍 Автоматичні перевірки

### Pre-commit hooks (рекомендовано):

```bash
# .git/hooks/pre-commit
#!/bin/bash

# Перевірка на credentials
if git diff --cached | grep -iE "(password|secret|api_key|private_key)" ; then
    echo "⚠️  ПОПЕРЕДЖЕННЯ: Можливо, ви commit'ите credentials!"
    echo "Перевірте зміни та видаліть конфіденційні дані."
    exit 1
fi

# Перевірка на .env файли
if git diff --cached --name-only | grep -E "\.env$" ; then
    echo "❌ ПОМИЛКА: Не можна commit'ити .env файли!"
    exit 1
fi
```

## 📞 Контакти безпеки

**Security Team:**
- Email: security@bank.gov.ua
- Emergency: +380 44 XXX-XXXX (тільки критичні інциденти)

**Project Owner:**
- Email: sep@bank.gov.ua
- Департамент платіжних систем НБУ

## 🔄 Оновлення політики

Ця політика безпеки переглядається кожні 6 місяців або при виникненні інцидентів.

**Остання перевірка:** 2026-02-06
**Наступна перевірка:** 2026-08-06

---

© 2026 Національний банк України. Конфіденційно.
